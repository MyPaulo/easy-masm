def binary_to_decimal(binary_str):
    """Convert a binary string to decimal."""
    return int(binary_str, 2)

def decimal_to_binary(decimal_num, length):
    """Convert a decimal number to binary with a specified length, using two's complement if negative."""
    if decimal_num < 0:
        # Calculate two's complement
        decimal_num = (1 << length) + decimal_num  # Add 2^length to the negative result
    # Convert to binary and remove the '0b' prefix
    bin_result = bin(decimal_num)[2:]
    # Ensure the result is of the specified length
    return bin_result.zfill(length)

def binary_addition(bin1, bin2):
    """Add two binary strings and return the result as a binary string."""
    num1 = binary_to_decimal(bin1)
    num2 = binary_to_decimal(bin2)
    result = num1 + num2
    max_length = max(len(bin1), len(bin2))
    return decimal_to_binary(result, max_length), result

def binary_subtraction(bin1, bin2):
    """Subtract bin2 from bin1 and return the result as a binary string."""
    num1 = binary_to_decimal(bin1)
    num2 = binary_to_decimal(bin2)
    result = num1 - num2
    max_length = max(len(bin1), len(bin2))
    return decimal_to_binary(result, max_length), result

def binary_multiplication(bin1, bin2):
    """Multiply two binary strings and return the result as a binary string."""
    num1 = binary_to_decimal(bin1)
    num2 = binary_to_decimal(bin2)
    result = num1 * num2
    max_length = len(bin(num1).replace('0b', '')) + len(bin(num2).replace('0b', ''))  # maximum length for the result
    return decimal_to_binary(result, max_length), result

def hex_to_decimal(hex_str):
    """Convert a hexadecimal string to decimal."""
    return int(hex_str, 16)

def decimal_to_hex(decimal_num):
    """Convert a decimal number to hexadecimal."""
    return hex(decimal_num)[2:].upper()  # Remove '0x' prefix and convert to uppercase

def hex_subtraction(hex1, hex2):
    """Subtract hex2 from hex1 and return the result as a hexadecimal string."""
    num1 = hex_to_decimal(hex1)
    num2 = hex_to_decimal(hex2)
    result = num1 - num2
    return decimal_to_hex(result), result

def binary_to_hex(binary_str):
    """Convert a binary string to hexadecimal."""
    decimal_num = int(binary_str, 2)
    hex_result = hex(decimal_num)[2:].upper()  # Remove '0x' prefix and convert to uppercase
    return hex_result, decimal_num

def hex_to_binary(hex_num):
    """Convert a hexadecimal string to binary."""
    decimal_num = int(hex_num, 16)
    binary_num = bin(decimal_num)[2:]
    return binary_num.zfill(4 * len(hex_num)), decimal_num

def display_menu():
    """Display the menu options."""
    print("Select an operation:")
    print("1. Binary Addition")
    print("2. Binary Subtraction")
    print("3. Binary Multiplication")
    print("4. Hexadecimal Subtraction")
    print("5. Binary to Hexadecimal Conversion")
    print("6. Hexadecimal to Binary Conversion")
    print("7. Exit")

def main():
    while True:
        display_menu()
        choice = input("Enter your choice (1-7): ")

        if choice == '1':
            bin1 = input("Enter the first binary number: ")
            bin2 = input("Enter the second binary number: ")
            if bin1 and bin2:
                num1 = binary_to_decimal(bin1)
                num2 = binary_to_decimal(bin2)
                print(f"Decimal value of {bin1}: {num1}")
                print(f"Decimal value of {bin2}: {num2}")
                result_bin, result_dec = binary_addition(bin1, bin2)
                print(f"Addition Result: {result_bin} (Decimal: {result_dec})")
            else:
                print("Invalid input. Please enter valid binary numbers.")

        elif choice == '2':
            bin1 = input("Enter the first binary number: ")
            bin2 = input("Enter the second binary number: ")
            if bin1 and bin2:
                num1 = binary_to_decimal(bin1)
                num2 = binary_to_decimal(bin2)
                print(f"Decimal value of {bin1}: {num1}")
                print(f"Decimal value of {bin2}: {num2}")
                result_bin, result_dec = binary_subtraction(bin1, bin2)
                print(f"Subtraction Result: {result_bin} (Decimal: {result_dec})")
            else:
                print("Invalid input. Please enter valid binary numbers.")

        elif choice == '3':
            bin1 = input("Enter the first binary number: ")
            bin2 = input("Enter the second binary number: ")
            if bin1 and bin2:
                num1 = binary_to_decimal(bin1)
                num2 = binary_to_decimal(bin2)
                print(f"Decimal value of {bin1}: {num1}")
                print(f"Decimal value of {bin2}: {num2}")
                result_bin, result_dec = binary_multiplication(bin1, bin2)
                print(f"Multiplication Result: {result_bin} (Decimal: {result_dec})")
            else:
                print("Invalid input. Please enter valid binary numbers.")

        elif choice == '4':
            hex1 = input("Enter the first hexadecimal number: ")
            hex2 = input("Enter the second hexadecimal number: ")
            if hex1 and hex2:
                num1 = hex_to_decimal(hex1)
                num2 = hex_to_decimal(hex2)
                print(f"Decimal value of {hex1}: {num1}")
                print(f"Decimal value of {hex2}: {num2}")
                result_hex, result_dec = hex_subtraction(hex1, hex2)
                print(f"Subtraction of {hex1} - {hex2}: {result_hex} (Decimal: {result_dec})")
            else:
                print("Invalid input. Please enter valid hexadecimal numbers.")

        elif choice == '5':
            binary_input = input("Enter a binary number: ")
            if binary_input:
                hex_result, decimal_result = binary_to_hex(binary_input)
                print(f"The hexadecimal equivalent of {binary_input} is: {hex_result} and {decimal_result} in decimal")
            else:
                print("Invalid input. Please enter a valid binary number.")

        elif choice == '6':
            hex_num = input("Enter a hexadecimal number: ")
            if hex_num:
                binary_num, decimal_num = hex_to_binary(hex_num)
                print(f"The binary equivalent of {hex_num} is {binary_num} (Decimal: {decimal_num})")
            else:
                print("Invalid input. Please enter a valid hexadecimal number.")

        elif choice == '7':
            print("Exiting the program.")
            break

        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
