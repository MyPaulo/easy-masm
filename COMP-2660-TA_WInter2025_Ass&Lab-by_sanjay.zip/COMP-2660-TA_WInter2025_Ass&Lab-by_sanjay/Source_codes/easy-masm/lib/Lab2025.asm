TITLE

; Name: Vansha Sakkarwal
; Date: 
; ID: 
; Description: LAB 1

INCLUDE Irvine32.inc
INCLUDELIB Irvine32.lib

; these two lines are only necessary if you're not using Visual Studio
INCLUDELIB kernel32.lib
INCLUDELIB user32.lib


.data
Var1 DWORD 10000h
Var2 DWORD 20000h
Var3 DWORD 3
Var4 DWORD -5

.code
main PROC
    ; Task 1: Adding Var1 and Var2
    Mov eax, Var1
    ADD eax, Var2
    call DumpRegs    ; Call function to display register contents
    Comment @
    Answer to Q1:
    The final value of the EAX register after adding Var1 (10000h) and Var2 (20000h) is 30000h (hex), 
    which is 196608 in signed decimal form.
    @
    

    ; Task 2: Adding Var3 and Var4
    Mov eax, Var3
    ADD eax, Var4
    Comment @
    The final value of the EAX register after adding Var3 (+3) and Var4 (-5) is FFFFFFFEh (hex) or -2 in signed decimal, 
    which is -2 in signed decimal form.
    @
    call DumpRegs    ; Call function to display register contents

    ret
main ENDP
END main