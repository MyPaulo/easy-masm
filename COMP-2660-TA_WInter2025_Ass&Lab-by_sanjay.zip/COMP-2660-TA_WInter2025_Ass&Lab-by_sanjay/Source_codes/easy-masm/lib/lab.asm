TITLE

; Name: 
; Date: 
; ID: 
; Description: 

INCLUDE Irvine32.inc
INCLUDELIB Irvine32.lib

; these two lines are only necessary if you're not using Visual Studio
INCLUDELIB kernel32.lib
INCLUDELIB user32.lib


.DATA
    arr1 DWORD 10, 21, 30, 41, 50, 61, 70, 81, 90, 101  ; Original array
    arr3 DWORD 10 DUP(?)  ; Destination array (for reversed evens)
    arrSize DWORD 10       ; Number of elements in arr1
    newline BYTE 10, 13, 0 ; Newline for formatting
    arr3Msg BYTE "Reversed Even Numbers: ", 0

.CODE
main PROC
    call PushEvenNumbers    ; Push even numbers onto stack
    call PopToArr3          ; Pop from stack to arr3 (reverse order)
    call PrintArr3          ; Print arr3
    exit
main ENDP

; ---------------------- PushEvenNumbers Procedure ----------------------
PushEvenNumbers PROC
    ; Pushes even numbers from arr1 onto the stack
    ; Uses: ESI (index), EAX (current value)
    
    mov esi, OFFSET arr1     ; Load address of arr1
    mov ecx, arrSize         ; Load number of elements

PushLoop:
    cmp ecx, 0               ; If ECX == 0, exit
    je Done
    mov eax, [esi]           ; Load current value from arr1[esi]
    test eax, 1              ; Check if number is odd (bitwise AND with 1)
    jnz SkipPush             ; If odd, skip pushing
    push eax                 ; Push even number onto stack

SkipPush:
    add esi, 4               ; Move to next element
    loop PushLoop            ; Repeat for all elements

Done:
    ret
PushEvenNumbers ENDP

; ---------------------- PopToArr3 Procedure ----------------------
PopToArr3 PROC
    ; Pops even numbers from stack into arr3 (reverse order)
    ; Uses: ESI (destination index), EAX (popped value)
    
    mov esi, OFFSET arr3     ; Load address of arr3

PopLoop:
    cmp esp, OFFSET arr1     ; Stop if stack is empty (base address check)
    ja DonePop               ; If stack pointer <= arr1 base, stop
    pop eax                  ; Pop value from stack
    mov [esi], eax           ; Store in arr3
    add esi, 4               ; Move to next element
    jmp PopLoop              ; Repeat until stack is empty

DonePop:
    ret
PopToArr3 ENDP

; ---------------------- PrintArr3 Procedure ----------------------
PrintArr3 PROC
    ; Prints arr3 using indexed addressing
    mov edx, OFFSET arr3Msg
    call WriteString

    mov esi, OFFSET arr3     ; Load address of arr3

PrintLoop:
    cmp [esi], DWORD PTR 0   ; If arr3 contains no more values, stop
    je DonePrint
    mov eax, [esi]           ; Load arr3[ESI]
    call WriteDec            ; Print number
    mov al, ' '              ; Print space
    call WriteChar
    add esi, 4               ; Move to next element
    jmp PrintLoop            ; Repeat

DonePrint:
    mov edx, OFFSET newline  ; Print new line
    call WriteString
    ret
PrintArr3 ENDP

END main
