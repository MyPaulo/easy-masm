TITLE; Assignment 1

;NAME: Yixuan Wang
;Date: Oct. 21, 2024
;ID: 110132780
;Description:Q2) Using Direct and Indirect Addressing to Operate on Two Arrays

INCLUDE Irvine32.inc
INCLUDELIB Irvine32.lib

.data
array1 DWORD 10, 21, 30, 41, 50				; array as [10, 21, 30, 41, 50]
array2 DWORD 5, 10, 15, 20, 25				; array as [5, 10, 15, 20, 25]
resultArray DWORD 5 DUP(?)					; create an array with dword type, result is assume as [15, 11, 45, 21, 75]
.code
main PROC
	mov eax, array1							; store value of array1[0] in eax since both of them are 32 bits
	add eax, array2							; eax = array1[0]+array2[0]  by direct way
	mov resultArray, eax					; store rsult in resultArray[0] = 15

	mov eax, array1+4						; store value of array1[1] in eax since both of them are 32 bits
	sub eax, array2+4						; eax = array1[1]-array2[1]  by direct way
	mov resultArray+4, eax					; store rsult in resultArray[1] = 11

	mov esi, OFFSET array1 + 4			    ; esi points to array1[1]
	mov edi, OFFSET array2 + 4		    	; edi points to array2[1]
	mov ebx, OFFSET resultArray + 4			; ebx points to resultArray[1]
	mov ecx, 0								; store 3 in ecx that start from the third element

	L1: 
		cmp ecx, 3							; compare ecx with 5
		jge L4								; jump to L4 if ecx > = 3
		add esi, 4							; move to the next element of array 1
		add edi, 4							; move to the next element of array 2
		add ebx, 4							; move to the next element of resultArray
		mov eax, [esi]						; store value of esi in eax

		mov edx, ecx						; store ecx into edx 
		and edx, 1							; if it's even
		jz L2								; jump to L2 if Zero flag = 1
		jnz L3								; jump to L3 if zero flag = 0
	L2:
		add eax , [edi]						; add elements
		mov [ebx], eax						; store the result from eax to where ebx points to
		inc ecx								; increment ecx
		jmp L1								; jump to L1
	L3:
		sub eax , [edi]						; subtract elements
		mov [ebx], eax						; store the result from eax to where ebx points to
		inc ecx								; increment ecx
		jmp L1								; jump L1

	L4:
		xor ecx, ecx						; clear ecx
		jmp L5								; jump to L5 
	L5: 
		cmp ecx, 5							; compare value of edx with number 5, since edx is 0 at this time
		jge L6								; jump to L6
		mov eax, [resultArray + 4 * ecx]	; mov element in eax one by one
		call WriteDec						; output decimal value
		call Crlf							; new line
		inc ecx								; ecx  =  edx + 1
		jmp L5								; repeat L5 steps

	L6:
		CALL DumpRegs						; output registers and flags
	exit
main ENDP
END main