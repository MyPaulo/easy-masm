TITLE

; Name: 
; Date: 
; ID: 
; Description: 

INCLUDE Irvine32.inc
INCLUDELIB Irvine32.lib

; these two lines are only necessary if you're not using Visual Studio
INCLUDELIB kernel32.lib
INCLUDELIB user32.lib

.data
x1 word 10H, 20H 
x2 word 30H, 40H
.code
main PROC
 
 
MOV ECX, LENGTHOF X1 
MOV ESI, OFFSET X1 
MOV EDI, OFFSET X2
 
L1: MOV AX, WORD PTR [ESI] 
	MOV DX, WORD PTR [EDI] 
	MOV [ESI],DX 
	MOV [EDI], AX 
	ADD ESI,2 
	ADD EDI,2 
LOOP L1
call DumpRegs

LEA ESI, x1   
mov ecx, SIZEOF x1             
call DumpMem   

LEA ESI, X2   
mov ecx, SIZEOF x2             
call DumpMem 
 
 
main ENDP
END main
