TITLE

; Name: 
; Date: 
; ID: 
; Description: 

INCLUDE Irvine32.inc
INCLUDELIB Irvine32.lib

; these two lines are only necessary if you're not using Visual Studio
INCLUDELIB kernel32.lib
INCLUDELIB user32.lib

COMMENT ! Q1
.data
.code
main PROC
xor eax,eax
xor ebx,ebx
xor ecx,ecx
 
mov eax,1
mov ecx,2
 
Label1:
    push ecx
    mov ebx,3
    mov ecx,2
    Label2:
        add eax,2
    loop Label2
    pop ecx
    loop Label1
    dec ecx
    mov ebx,ecx
    add ebx,2
    nop
	call DumpRegs ; displays registers in console

	exit

main ENDP
END main

!

