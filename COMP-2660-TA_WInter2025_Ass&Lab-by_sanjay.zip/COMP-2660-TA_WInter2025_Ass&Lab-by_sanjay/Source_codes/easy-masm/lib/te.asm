INCLUDE Irvine32.inc
INCLUDELIB Irvine32.lib
; these two lines are only necessary if you're not using Visual Studio
INCLUDELIB kernel32.lib
INCLUDELIB user32.lib


.DATA
align 4
var1 BYTE 12h
var2 WORD 3456h
var3 DWORD 789ABCDEh
arr1 DWORD 10, 21, 30, 41, 50, 61, 70, 81, 90, 101  ; Given array
arr2 DWORD 10 DUP(?)           ; Array for copied values
arr3 DWORD 10 DUP(?)           ; Array for reversed even numbers
str1 BYTE "Assembly Programming", 0
matrix DWORD 4 DUP(4 DUP(?))   ; 4x4 uninitialized matrix
newline BYTE 13, 10, 0         ; Newline for formatting
space   BYTE " ", 0            ; Space for formatting

.CODE

;--------------------------------------------
; Procedure to initialize the 4x4 matrix with values 1-16
;--------------------------------------------
InitMatrix PROC
    PUSH ESI
    PUSH EDI
    MOV ECX, 16                ; 4x4 = 16 elements
    MOV EAX, 1                 ; Start from 1
    LEA EDI, matrix            ; Save the matrix address

FillLoop:
    MOV [EDI], EAX             ; Save the value
    ADD EDI, 4                 ; Move to next DWORD
    INC EAX                    ; Increment value
    LOOP FillLoop              ; Repeat for 16 values

    POP EDI
    POP ESI
    RET
InitMatrix ENDP

;--------------------------------------------
; Procedure to print the 4x4 matrix
;--------------------------------------------
PrintMatrix PROC
    PUSH ESI
    MOV ESI, OFFSET matrix
    MOV ECX, 4                 ; Rows

RowLoop:
    PUSH ECX
    MOV ECX, 4                 ; Columns

ColLoop:
    MOV EAX, [ESI]             ; Save the value
    CALL WriteDec              ; Print number

    MOV  EDX, OFFSET space      ; Save the space string
    CALL WriteString           ; Print space
    
    ADD ESI, 4                 ; Move to next DWORD
    LOOP ColLoop

    CALL Crlf                  ; Newline after row
    POP ECX
    LOOP RowLoop

    POP ESI
    RET
PrintMatrix ENDP

;--------------------------------------------
; Procedure to copy arr1 into arr2 dynamically using the stack
;--------------------------------------------
CopyArray PROC
    PUSH ESI
    PUSH EDI
    MOV ECX, 10                ; Number of elements
    LEA ESI, arr1              ; Save source array address
    LEA EDI, arr2              ; Save destination array address

CopyLoop:
    MOV EAX, [ESI]             ; Save the value from arr1
    MOV [EDI], EAX             ; Save in arr2
    ADD ESI, 4                 ; Move to next element
    ADD EDI, 4                 ; Move to next element
    LOOP CopyLoop

    POP EDI
    POP ESI
    RET
CopyArray ENDP

;--------------------------------------------
; Procedure to print an array (Used for arr1 and copied array)
;--------------------------------------------
PrintArray PROC
    PUSH ESI
    MOV ESI, EAX               ; Save array address
    MOV ECX, 10                ; Number of elements

PrintLoop:
    MOV EAX, [ESI]             ; Save the value
    CALL WriteDec              ; Print number

    MOV  EDX, OFFSET space      ; Save the space string
    CALL WriteString           ; Print space

    ADD ESI, 4                 ; Move to next element
    LOOP PrintLoop

    CALL Crlf
    POP ESI
    RET
PrintArray ENDP

;--------------------------------------------
; Procedure to push even numbers from arr1 onto the stack
;--------------------------------------------
PushEvenNumbers PROC
    PUSH ESI
    MOV ECX, 10                ; Number of elements
    LEA ESI, arr1              ; Save arr1 address

PushLoop:
    MOV EAX, [ESI]             ; Save the value
    TEST EAX, 1                ; Check if even (last bit 0)
    JNZ SkipPush               ; If odd, skip pushing

    PUSH EAX                   ; Push even number onto stack

SkipPush:
    ADD ESI, 4                 ; Move to next element
    LOOP PushLoop

    POP ESI
    RET
PushEvenNumbers ENDP

;--------------------------------------------
; Procedure to pop even numbers from stack into arr3 (Reversed order)
;--------------------------------------------
PopReverseArray PROC
    PUSH ESI
    LEA ESI, arr3              ; Save the address of arr3
    MOV ECX, 10                ; Number of even numbers to pop

PopLoop:
    POP EAX                    ; Pop value from stack
    MOV [ESI], EAX             ; Save in arr3
    ADD ESI, 4                 ; Move to next element
    LOOP PopLoop

    POP ESI
    RET
PopReverseArray ENDP

;--------------------------------------------
; Main program
;--------------------------------------------
MAIN PROC
    ; Step 1: Initialize and print 4x4 matrix
    CALL InitMatrix
    CALL PrintMatrix
    CALL Crlf

    ; Step 2: Copy arr1 to arr2 and print both arrays
    CALL CopyArray
    MOV EAX, OFFSET arr1
    CALL PrintArray             ; Print arr1
    MOV EAX, OFFSET arr2
    CALL PrintArray             ; Print arr2

    CALL Crlf

    ; Step 3: Push even numbers to stack, pop into reversed array, and print
    CALL PushEvenNumbers
    CALL PopReverseArray
    MOV EAX, OFFSET arr3
    CALL PrintArray             ; Print reversed array

    INVOKE ExitProcess, 0
MAIN ENDP

END MAIN
