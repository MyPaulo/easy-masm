TITLE

; Name: 
; Date: 
; ID: 
; Description: 

INCLUDE Irvine32.inc
INCLUDELIB Irvine32.lib

; these two lines are only necessary if you're not using Visual Studio
INCLUDELIB kernel32.lib
INCLUDELIB user32.lib

.data
	; data declarations go here
     byte1 BYTE 10,20,30,40
     array1 WORD 30 DUP(?), 0,0
     array2 WORD 5 DUP(3 DUP(?))
     array3 DWORD 01234567h, 2,3,4
     digitStr BYTE '12345678',0
     myArray BYTE 10h, 20h, 30h, 40h, 50h, 60h, 70h, 80h, 90h
     
	
.code
main PROC
	
	; code goes here

	xor eax, eax
    xor ebx, ebx
    xor ecx, ecx
    xor edx, edx
    COMMENT @
    ; Demonstrating TYPE operator ; return size of single element
    mov al, TYPE byte1
    mov bl, TYPE array1
    mov cl, TYPE array3
    mov dl, TYPE digitStr
    call DumpRegs ; displays registers in console
    @
    COMMENT @
    ; Demonstrating LENGTHOF operator return total number of item in array
    mov eax, LENGTHOF array1
    mov ebx, LENGTHOF array2
    mov ecx, LENGTHOF array3
    mov edx, LENGTHOF digitStr
    call DumpRegs ; displays registers in console
    @

    COMMENT @
    ; Demonstrating SIZEOF operator
    mov eax, SIZEOF array1
    mov ebx, SIZEOF array2
    mov ecx, SIZEOF array3
    mov edx, SIZEOF digitStr
    call DumpRegs ; displays registers in console
    @
    COMMENT @
    ; Demonstrating OFFSET operator
    mov eax, OFFSET byte1
    mov ebx, OFFSET array1
    mov ecx, OFFSET array2
    mov edx, OFFSET array3
    mov esi, OFFSET digitStr
    mov edi, OFFSET myArray
    call DumpRegs ; displays registers in console
    @

    COMMENT @
    ; Demonstrating PTR operator
    mov al, BYTE PTR array3
    mov bx, WORD PTR array3
    mov cx, WORD PTR myArray
    mov edx, DWORD PTR myArray
    call DumpRegs ; displays registers in console
    @



    LEA ESI, byte1   ; Point to the array
    mov ecx, SIZEOF byte1              ; 5 DWORDs = 20 bytes
    call DumpMem            ; Display memory contents

    LEA ESI, array1   ; Point to the array
    mov ecx, SIZEOF array1              ; 5 DWORDs = 20 bytes
    call DumpMem            ; Display memory contents
    

    LEA ESI, array2   ; Point to the array
    mov ecx, SIZEOF array2              ; 5 DWORDs = 20 bytes
    call DumpMem            ; Display memory contents

    LEA ESI, array3   ; Point to the array
    mov ecx, SIZEOF array3              ; 5 DWORDs = 20 bytes
    call DumpMem            ; Display memory contents
	
    LEA ESI, digitStr   ; Point to the array
    mov ecx, SIZEOF digitStr              ; 5 DWORDs = 20 bytes
    call DumpMem            ; Display memory contents

    LEA ESI, myArray   ; Point to the array
    mov ecx, SIZEOF myArray              ; 5 DWORDs = 20 bytes
    call DumpMem            ; Display memory contents
    

	exit

main ENDP
END main
