TITLE

; Name: 
; Date: 
; ID: 
; Description: 

INCLUDE Irvine32.inc
INCLUDELIB Irvine32.lib

; these two lines are only necessary if you're not using Visual Studio
INCLUDELIB kernel32.lib
INCLUDELIB user32.lib

.data    ; Data declarations go here
varX word 10     ; Variable X initialized to 10
varY word 15     ; Variable Y initialized to 15
varR word 4      ; Variable R initialized to 4
varZ DWORD 3 DUP(?)  ; varZ array of DWORDs uninitialized

.code
main PROC
    ; Zero out registers to avoid unexpected values
    XOR EAX, EAX
    XOR EBX, EBX
    XOR ECX, ECX
    XOR EDX, EDX

    ; Calculate z0 = x + 130
    MOV DX, varX    ; Move value of varX (10) into register DX
    ADD DX, 130     ; Add 130 to DX (x + 130 = 140)
    MOV AX, DX      ; Move result (140) into AX (AX = z0)

    ; Calculate z1 = y - x + z0
    MOV BX, varY ; move value of varY(15) into BX
    SUB BX, varX ; subtract varX(10) from BX(15-10 = 5)
    ADD BX, AX ; add value of AX(140) to BX, BX = 145 = z1=91 in hex
    
    ; Calculate z2 = r + x - z1
    MOV DX, varR    ; Move value of varR (4) into register DX
    ADD DX, varX    ; Add varX (10) to DX (r + x = 14)
    SUB DX, BX      ; Subtract z1 (145) from DX (14 - 145 = -131)
    MOV CX, DX      ; Move result (-131) into CX (CX = z2=0000FF7D)

    ; Convert values to 32-bit and store in varZ array
    MOVZX EAX, AX   ; Zero-extend AX to 32-bit EAX 
    MOVZX EBX, BX   ; Zero-extend BX to 32-bit EBX
    MOVSX ECX, CX   ; Sign-extend CX to 32-bit ECX 
    
    MOV varZ, EAX   ; Store z0 in the first element of varZ
    MOV varZ + 4, EBX ; Store z1 in the second element of varZ
    call Crlf 
    MOV varZ + 8, ECX ; Store z2 in the third element of varZ

;print the content of the array 
;"LEA EAX, varZ" is the same as "MOV EAX, OFFSET varZ"
    MOV EAX, OFFSET varZ ; Move the address (offset) of varZ into EAX
    MOV EAX, [varZ] ; same as MOV EAX,[varZ + 0]
    call WriteHex           ; Call procedure to print Hexdecimal
    call Crlf               ; Print newline
    MOV EAX, [varZ + 4]
    call WriteHex          
    call Crlf 
    MOV EAX, [varZ + 8]
    call WriteHex          
    call Crlf

    mov esi, OFFSET varZ        ; Point to z
    mov ecx, 12              ; 3 DWORDs = 12 bytes
    call DumpMem  
COMMENT @
    ; Loop to print values of varZ array
    MOV ECX, 0        ; Initialize index to 0
L1:
    CMP ECX, 3        ; Compare index with array size
    JGE L2      ; If index >= 3, end loop 
    ; Print current array element
    MOV EAX, varZ[ECX * 4] ; Move array element into EAX (4 bytes per DWORD)
    call WriteHex           ; Call procedure to print Hexdecimal
    call Crlf               ; Print newline
    INC ECX; Increment index
    JMP L1 ; Repeat loop
L2:
    @
    ; Display registers in console
    call DumpRegs

    exit
main ENDP
END main


















































COMMENT @




TITLE

; Name: 
; Date: 
; ID: 
; Description: 

INCLUDE Irvine32.inc
INCLUDELIB Irvine32.lib

; these two lines are only necessary if you're not using Visual Studio
INCLUDELIB kernel32.lib
INCLUDELIB user32.lib






; Name: Ayesha Shakeel
; Student ID: 110155047
; 110155047.asm
; Purpose: This program will compute the values for the array z

; x = 10, y = 15, r = 4
; z[0] = x + 130
; z[1] = y - x + z[0]
; z[2] = r + x - z[1]

;.386                        ; Enable 32-bit instructions
;.model flat, stdcall         ; Flat memory model
;.stack 4096                 ; 4KB stack

ExitProcess PROTO, dwExitCode:DWORD

.data

; Declare the 16-bit variables x, y, r
x WORD 10            ; x = 10
y WORD 15            ; y = 15
r WORD 4            ; r = 4


; Declare the z array of size 3 (DWORD aligned)
z DWORD 3 DUP(?)

.code
main PROC

; Step 1: Calculate z[0] = x + 130
movzx eax, x                ; Move x into eax, sign extend (correct for signed interpretation)
add eax, 130                ; eax = eax + 130, so eax = 10 + 130 = 140
mov z, eax                    ; Store the result into z[0] (explicit 32-bit store)

; Step 2: Calculate z[1] = y - x + z[0]
movzx eax, y                ; Move y into eax, sign extend (explicit 16-bit access)
movzx ebx, x                ; Move x into ebx, sign extend to avoid modifying eax
sub eax, ebx                ; eax = eax - ebx = 15 - 10 = 5
add eax, [z]                ; eax = eax + z[0] = 5 + 140 = 145
mov [z+4], eax                ; Store the result into z[1] (explicit 32-bit store at z+4)
;call WriteHex

; Step 3: Calculate z[2] = r + x - z[1]
movzx eax, r                ; Move r into eax, sign extend (explicit 16-bit access)
movzx ebx, x                ; Move x into ebx, sign extend
add eax, ebx                ; eax = eax + ebx = 4 + 10 = 14
sub eax, z+4                ; eax = eax - z[1] = 14 - 145 = -131
mov z+8, eax                ; Store the result into z[2] (explicit 32-bit store at z+8)



 MOV EAX, OFFSET z ; Move the address (offset) of varZ into EAX
    MOV EAX, [z] ; same as MOV EAX,[varZ + 0]
    call WriteHex           ; Call procedure to print Hexdecimal
    call Crlf               ; Print newline
    MOV EAX, [z + 4]
    call WriteHex          
    call Crlf 
    MOV EAX, [z + 8]
    call WriteHex          
    call Crlf





; Display registers in console
    call DumpRegs

; Exit
INVOKE ExitProcess, 0

main ENDP
END main

@
