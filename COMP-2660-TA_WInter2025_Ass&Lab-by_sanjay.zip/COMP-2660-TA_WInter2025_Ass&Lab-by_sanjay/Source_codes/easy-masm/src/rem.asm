TITLE

; Name: 
; Date: 
; ID: 
; Description: 

INCLUDE Irvine32.inc
INCLUDELIB Irvine32.lib

; these two lines are only necessary if you're not using Visual Studio
INCLUDELIB kernel32.lib
INCLUDELIB user32.lib

.data
    inputString BYTE 100 DUP(0)                          ; reserve 100 bytes for user input
    promptMsg   BYTE "Enter a string: ", 0
    resultMsg   BYTE "Sum of individual digits is: ", 0
    sum         DWORD 0                                  ; variable to hold final sum

.code
main PROC
    ;the user for input
    mov edx, OFFSET promptMsg
    call WriteString

    ;string input from keyboard
    mov edx, OFFSET inputString
    mov ecx, SIZEOF inputString
    call ReadString

    ;initialize register
    mov ecx, 0                                           ; index = 0
    mov esi, OFFSET inputString
    mov eax, 0                                           ; sum = 0 in AL (low byte)

nextChar:
    mov bl, [esi + ecx]                                  ; load next character into BL
    cmp bl, 0                                            ; check for null terminator (end of string)
    je done

    ;if character is a digit (ASCII '0' to '9')
    cmp bl, '0'
    jb skip                                              ; less than '0', not a digit
    cmp bl, '9'
    ja skip                                              ; greater than '9', not a digit

    ;digit => ASCII to actual digit
    and bl, 0Fh                                          ; upper bits: ASCII => integer
    add al, bl                                           ; digit to running sum

skip:
    inc ecx                                              ; to next character
    jmp nextChar

done:
    ; output the result
    movzx eax, al                                         ; zero-extend AL into EAX for printing
    call Crlf
    mov edx, OFFSET resultMsg
    call WriteString
    call WriteDec
    call Crlf

    exit
main ENDP
END main
