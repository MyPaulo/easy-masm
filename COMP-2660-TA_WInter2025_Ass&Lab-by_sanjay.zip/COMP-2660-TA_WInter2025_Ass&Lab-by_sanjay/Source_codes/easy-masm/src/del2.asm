TITLE

; Name: 
; Date: 
; ID: 
; Description: 

INCLUDE Irvine32.inc
INCLUDELIB Irvine32.lib

; these two lines are only necessary if you're not using Visual Studio
INCLUDELIB kernel32.lib
INCLUDELIB user32.lib

.data
	; data declarations go here
	myWord  DWORD 48, 0056, "E"
    mybyte byte -1, 20, 7
    myArray1 WORD 1h,2h,0045h,"A"
    myArray2 DWORD 3h, 4h
.code
main PROC
	

    LEA ESI, myWord
    MOV ECX, SIZEOF myWord
    call DumpMem
    LEA ESI, mybyte
    MOV ECX, SIZEOF mybyte
    call DumpMem

    LEA ESI, myArray1
    MOV ECX, SIZEOF myArray1
    call DumpMem

    LEA ESI, myArray2
    MOV ECX, SIZEOF myArray2
    call DumpMem
	; code goes here
	call DumpRegs ; displays registers in console

	exit

main ENDP
END main
