TITLE
; Name: 
; Date: 
; ID: 
; Description: 

INCLUDE Irvine32.inc
INCLUDELIB Irvine32.lib

; these two lines are only necessary if you're not using Visual Studio
INCLUDELIB kernel32.lib
INCLUDELIB user32.lib
.data
	; data declarations go here
    align 4
    var1 BYTE 12h
    var2 WORD 3456h
    var3 DWORD 789ABCDEh
    arr1 DWORD 10, 21, 30, 41, 50, 61, 70, 81, 90, 101
    str1 BYTE "Assembly Programming", 0
    matrix DWORD 4 DUP(4 DUP(?)) ; 4x4 Matrix
    uninit DWORD ?

.code
;Procedure for initializing matrix
MatrixFill PROC
    push ebp
    mov ebp, esp
    pushad
    mov esi, [ebp+12]  ; offset or address of matrix
    mov ecx, [ebp+8]  ; matrix size 
    mov eax, 0 ; to be used for numbers
    L1:
        inc eax
        ;call DumpRegs ;for debugging
        mov [esi], eax ; store the value in the matrix
        add esi, TYPE DWORD ;move to next index of array
        Loop L1

        popad
        pop ebp
    ret 8 ;clean up the stack
MatrixFill ENDP

;Procedure for printing the matrix
PrintMatrix PROC
    call CRLF
    lea esi, matrix
    mov ecx, 4
    display_rows:
        push ecx
        mov ecx, 4
    display_cols:
        mov eax,[esi]
        call WriteDec
        mov al, ' '
        call WriteChar
        add esi, TYPE DWORD
        Loop display_cols
        call CRLF
        pop ecx
        Loop display_rows
    ret
PrintMatrix ENDP

main PROC
    ;Print the matrix before initialization
    call PrintMatrix
	;Initialize the matrix
    push offset matrix
    push 16
    call MatrixFill
    ;Print the matrix after initialization
    call PrintMatrix
	call DumpRegs ; displays registers in console
	exit

main ENDP
END main



