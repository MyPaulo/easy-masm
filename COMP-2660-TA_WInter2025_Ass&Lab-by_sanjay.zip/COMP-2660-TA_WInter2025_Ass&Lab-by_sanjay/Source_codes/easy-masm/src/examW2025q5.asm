TITLE

; Name: 
; Date: 
; ID: 
; Description: 

INCLUDE Irvine32.inc
INCLUDELIB Irvine32.lib

; these two lines are only necessary if you're not using Visual Studio
INCLUDELIB kernel32.lib
INCLUDELIB user32.lib

.data

.code
main PROC

COMMENT !  ;a
MOV AX, 90F8h
MOV CX, 08h

L1: SHRD AX, CX, 1

    JC L2

LOOP L1

L2: RET

call DumpRegs 
!

;COMMENT  $
MOV AX, 10H
MOV CX, 0AH
L1:
    INC AX
    DEC CX
    LOOPNE L1
    nop
call DumpRegs 
;$

COMMENT @
mov ecx, 4
mov eax, 1
shift_loop:
shl eax, 1
loop shift_loop
call writeBin
call DumpRegs 
@
exit
main ENDP
END main
