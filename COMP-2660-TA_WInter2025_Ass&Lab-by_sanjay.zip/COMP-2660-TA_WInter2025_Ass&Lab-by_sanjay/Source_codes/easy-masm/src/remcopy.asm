TITLE Arithmetic Expression Evaluator ((A+B)/C)*((D-A)+E)

; Name: 
; Date: 
; ID: 
; Description: Evaluates the expression ((A+B)/C)*((D-A)+E) with test values

INCLUDE Irvine32.inc
INCLUDELIB Irvine32.lib

; these two lines are only necessary if you're not using Visual Studio
INCLUDELIB kernel32.lib
INCLUDELIB user32.lib

.data
    ; Variable declarations with test values
    A DWORD 5
    B DWORD 3
    varC DWORD 2
    D DWORD 7
    E DWORD 4
    
    ; Messages for output
    msgResult BYTE "The result of ((A+B)/C)*((D-A)+E) is: ",0

.code
main PROC
    ; Calculate (A+B)
    mov eax, A
    add eax, B      ; EAX = A + B
    
    ; Calculate (A+B)/C
    cdq             ; Extend EAX into EDX for division
    mov ebx, varC
    idiv ebx        ; EAX = (A+B)/C, EDX = remainder
    mov ecx, eax    ; Store intermediate result in ECX
    
    ; Calculate (D-A)
    mov eax, D
    sub eax, A      ; EAX = D - A
    
    ; Calculate (D-A)+E
    add eax, E      ; EAX = (D-A) + E
    
    ; Final multiplication: ECX * EAX
    imul eax, ecx   ; EAX = ECX * EAX
    
    ; Display the result
    mov edx, OFFSET msgResult
    call WriteString
    call WriteDec    ; Display the result in EAX
    call Crlf        ; New line
    
    ; Display registers (optional)
    call DumpRegs

    exit
main ENDP
END main