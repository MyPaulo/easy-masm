
TITLE Array Operations

; Name: 
; Date: 
; ID: 
; Description: This program performs addition and subtraction on elements of two arrays using both direct and indirect addressing

INCLUDE Irvine32.inc
INCLUDELIB Irvine32.lib

; These two lines are only necessary if you're not using Visual Studio
INCLUDELIB kernel32.lib
INCLUDELIB user32.lib

.data
array1 DWORD 10, 21, 30, 41, 50  ; Initialize the first array with 5 DWORD elements
array2 DWORD 5, 10, 15, 20, 25   ; Initialize the second array with 5 DWORD elements
resultArray DWORD 5 DUP(0)      ; Initialize resultArray with 5 DWORD elements


.code
main PROC

    ; Step 2: Use direct addressing to add the first elements of array1 and array2
    MOV EAX, array1          ; Load the first element of array1 (5) into EAX
    ADD EAX, array2          ; Add the first element of array2 (3) to EAX
    MOV resultArray, EAX     ; Store the result (8) in the first element of resultArray

    ; Step 3: Use direct addressing to subtract the second element of array2 from the second element of array1
    MOV EAX, array1[4]       ; Load the second element of array1 (10) into EAX
    SUB EAX, array2[4]       ; Subtract the second element of array2 (9) from EAX
    MOV resultArray[4], EAX  ; Store the result (1) in the second element of resultArray

    ; Step 4: Use indirect addressing for the remaining elements
    LEA ESI, array1          ; Load the address of array1 into ESI
    LEA EDI, array2          ; Load the address of array2 into EDI
    LEA EBX, resultArray     ; Load the address of resultArray into EBX

    ; Add the corresponding even index elements from array1 and array2
    MOV EAX, [ESI + 8]       ; Load the third element 
    ADD EAX, [EDI + 8]       ; Add the third element of array2 (12) to EAX = 27 or 1B
    MOV [EBX + 8], EAX       ; Store the result (27) in the third element of resultArray

    ; Subtract the corresponding odd index elements
    MOV EAX, [ESI + 12]      ; Load the fourth element of array1 (20) into EAX
    SUB EAX, [EDI + 12]      ; Subtract the fourth element of array2 (15) from EAX
    MOV [EBX + 12], EAX      ; Store the result (5) in the fourth element of resultArray

    ; Add the fifth elements
    MOV EAX, [ESI + 16]      ; Load the fifth element of array1 (25) into EAX
    ADD EAX, [EDI + 16]      ; Add the fifth element of array2 (18) to EAX
    MOV [EBX + 16], EAX      ; Store the result (43) in the fifth element of resultArray

   
   
    mov ECX, LENGTHOF resultArray
    LEA ESI, resultArray
    L2:
        MOV EAX, [ESI]
        call WriteDec
        ADD ESI, TYPE resultArray
        CALL CRLF
        ;ADD ESI, TYPE resultArray
        loop L2
    
    ; Step 5: Display the final contents of resultArray
    lea esi, resultArray     ; Point to resultArray
    mov ecx, SIZEOF resultArray            ; 5 DWORDs = 20 bytes
    call DumpMem             ; Display memory contents
    
    call DumpRegs            ; Display registers
   
    exit
main ENDP
END main

































































































































































COMMENT @

TITLE Array Operations
; Name: 
; Date: 
; ID: 
; Description: This program performs addition and subtraction on elements of two arrays using both direct and indirect addressing

INCLUDE Irvine32.inc
INCLUDELIB Irvine32.lib

; These two lines are only necessary if you're not using Visual Studio
INCLUDELIB kernel32.lib
INCLUDELIB user32.lib

.data
array1 DWORD 10, 21, 30, 41, 50  ; Initialize the first array with 5 DWORD elements
array2 DWORD 5, 10, 15, 20, 25   ; Initialize the second array with 5 DWORD elements
resultArray DWORD 5 DUP(0)      ; Initialize resultArray with 5 DWORD elements

.code
main PROC

    ; Step 2: Use direct addressing to add the first elements of array1 and array2 (even index)
    MOV EAX, array1          ; Load the first element of array1 (5) into EAX
    ADD EAX, array2          ; Add the first element of array2 (3) to EAX
    MOV resultArray, EAX     ; Store the result (8) in the first element of resultArray

    ; Step 3: Use direct addressing to subtract the second element of array2 from the second element of array1 (odd index)
    MOV EAX, array1[4]       ; Load the second element of array1 (10) into EAX
    SUB EAX, array2[4]       ; Subtract the second element of array2 (9) from EAX
    MOV resultArray[4], EAX  ; Store the result (1) in the second element of resultArray

    ; Step 4: Use indirect addressing for the remaining elements
    LEA ESI, array1          ; Load the address of array1 into ESI
    LEA EDI, array2          ; Load the address of array2 into EDI
    LEA EBX, resultArray     ; Load the address of resultArray into EBX
    ADD ESI, 8               ; Move to the third element of array1
    ADD EDI, 8               ; Move to the third element of array2
    ADD EBX, 8               ; Move to the third element of resultArray
    MOV ECX, 3               ; Set loop counter to 3 (remaining elements)

    ; Loop through the remaining elements
    L1:
        MOV EAX, [ESI]       ; Load element from array1 into EAX
        CMP ECX, 3           ; Check if it's the third element (even index)
        JE EVEN_INDEX          ; Jump to EVEN_INDEX if true
        CMP ECX, 1           ; Check if it's the fifth element (even index)
        JE EVEN_INDEX          ; Jump to EVEN_INDEX if true

        ; Subtract for odd index elements
        SUB EAX, [EDI]       ; Subtract element from array2 from EAX
        JMP STORE_RESULT     ; Jump to store the result

    EVEN_INDEX:
        ADD EAX, [EDI]       ; Add element from array2 to EAX

    STORE_RESULT:
        MOV [EBX], EAX       ; Store result in resultArray

        ADD ESI, 4           ; Move to the next element in array1
        ADD EDI, 4           ; Move to the next element in array2
        ADD EBX, 4           ; Move to the next element in resultArray

        LOOP L1              ; Repeat for all remaining elements

    MOV ECX, LENGTHOF resultArray
    LEA ESI, resultArray
    L2:
        mov EAX, [ESI]
        CALL WriteDec
        CALL CRLF
        ADD ESI, TYPE resultArray
        LOOP L2

    ;Display the final contents of resultArray
    LEA ESI, resultArray     ; Point to resultArray
    MOV ECX, 20              ; 5 DWORDs = 20 bytes
    CALL DumpMem             ; Display memory contents

    CALL DumpRegs            ; Display registers

    EXIT
main ENDP
END main

@

