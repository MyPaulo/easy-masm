TITLE

; Name: 
; Date: 
; ID: 
; Description: 

INCLUDE Irvine32.inc
INCLUDELIB Irvine32.lib

; these two lines are only necessary if you're not using Visual Studio
INCLUDELIB kernel32.lib
INCLUDELIB user32.lib

.data
a REAL4 5.0                
b REAL4 3.0                
c1 REAL4 10.0               
d REAL4 2.0                
e REAL4 4.0                
y REAL4 ?                 
 
.code
main PROC
    finit                   
    fld a  
    call showfpustack
    fadd b
    call showfpustack
    fstp st(1) 
    call showfpustack
    fld c1 
    call showfpustack
    fsub d 
    call showfpustack
    fmul 
    call showfpustack
    fld e 
    call showfpustack
    fdiv 
    call showfpustack
    fstp y  
    call showfpustack
    nop
    ; Exit program
    invoke ExitProcess, 0
main ENDP
 
END main
