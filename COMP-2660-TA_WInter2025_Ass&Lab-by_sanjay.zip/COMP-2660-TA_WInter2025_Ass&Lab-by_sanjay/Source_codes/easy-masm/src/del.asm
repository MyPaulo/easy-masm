TITLE

; Name: 
; Date: 
; ID: 
; Description: 

INCLUDE Irvine32.inc
INCLUDELIB Irvine32.lib

; these two lines are only necessary if you're not using Visual Studio
INCLUDELIB kernel32.lib
INCLUDELIB user32.lib

.code
main PROC
	push 3		; calc sum 3 down to 0
	call Factorial		; calculate factorial (eax)
ReturnMain:
	call WriteDec		; display it
	call Crlf
	exit
main ENDP

Factorial PROC
	push ebp
	mov  ebp,esp
	mov  eax,[ebp+8]		; get n
	cmp  eax,0		; n < 0?
	ja   L1		; yes: continue
	mov  eax,0		; no: return 1
	jmp  L2

L1: dec  eax
	push eax		; Factorial(n-1)
	call Factorial

; Instructions from this point on execute when each
; recursive call returns.

ReturnFact:

	add  eax, [ebp+8]          		; ax = ax * bx

L2: pop  ebp		; return EAX
	ret  4		; clean up stack
Factorial ENDP

END main