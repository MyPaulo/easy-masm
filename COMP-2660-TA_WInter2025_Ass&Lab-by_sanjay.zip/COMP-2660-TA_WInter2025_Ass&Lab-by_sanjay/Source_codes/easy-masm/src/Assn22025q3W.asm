

TITLE
; Name: 
; Date: 
; ID: 
; Description: 

INCLUDE Irvine32.inc
INCLUDELIB Irvine32.lib

; these two lines are only necessary if you're not using Visual Studio
INCLUDELIB kernel32.lib
INCLUDELIB user32.lib
.data
	; data declarations go here
    align 4
    var1 BYTE 12h
    var2 WORD 3456h
    var3 DWORD 789ABCDEh
    arr1 DWORD 10, 21, 30, 41, 50, 61, 70, 81, 90, 101
    str1 BYTE "Assembly Programming", 0
    matrix DWORD 4 DUP(4 DUP(?)) ; 4x4 Matrix
    uninit DWORD ?
    arr2 DWORD 10 DUP (?)

.code

;Procedure for printing content of an array
PrintArray PROC
    push ebp
    mov ebp,esp
    pushad

    mov esi, [ebp+12] ;Load address of the array into ESI
    mov ecx, [ebp+8] ;; Load length of the array into ECX
  

    call CRLF
    L1:
        mov eax, [esi]
        call WriteDec
        mov al, ' '
        call WriteChar
        add esi, TYPE DWORD
        Loop L1

        call CRLF
        popad
        pop ebp
    ret 8
PrintArray ENDP

;Procedure for copying array(arr1) to arr2
ArrayCopy PROC
    lea esi, arr1 ;Load address of arr1 into ESI
    lea edi, arr2 ;; Load address of arr2 into EDI
    mov ecx, LENGTHOF arr1
    L1:
        mov eax, [esi]; Load first value from arr1 into EAX
        mov [edi], eax ;store the value in edi(arr2)
        add esi, TYPE arr1; go to the next index in arr1
        add edi, TYPE arr2; go to the next index in arr2
        Loop L1

    ret
ArrayCopy ENDP

main PROC
	
    ; display the original array before copying
    push OFFSET arr1
    push LENGTHOF arr1
    call PrintArray

     ;Copy arr1 to arr2
    ;call ArrayCopy
	
    ;display the copied array
    push OFFSET arr2
    push LENGTHOF arr2
    call PrintArray


	;call DumpRegs ; displays registers in console
	exit

main ENDP
END main



