TITLE

; Name: 
; Date: 
; ID: 
; Description: 

INCLUDE Irvine32.inc
INCLUDELIB Irvine32.lib

; these two lines are only necessary if you're not using Visual Studio
INCLUDELIB kernel32.lib
INCLUDELIB user32.lib

.data
	; data declarations go here
    x1 sword 8F7AH, 7AF8H
    x2 word 0000h
	
.code
main PROC
	
	; code goes here
	xor eax, eax
    MOV AX, x1 
    ADD AX, [x1+2]      ; Flag  CF          SF	         ZF  
    call DumpRegs
    nop
    MOV ESI, OFFSET x2
 
    MOV BX, [ESI] 
    SUB BX, 1           ; Flag  CF          SF	         ZF
	call DumpRegs ; displays registers in console

	exit

main ENDP
END main
