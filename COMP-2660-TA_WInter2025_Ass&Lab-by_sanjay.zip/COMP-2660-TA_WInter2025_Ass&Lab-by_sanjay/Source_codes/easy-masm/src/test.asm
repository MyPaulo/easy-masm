TITLE

; Name: 
; Date: 
; ID: 
; Description: 

INCLUDE Irvine32.inc
INCLUDELIB Irvine32.lib

; these two lines are only necessary if you're not using Visual Studio
INCLUDELIB kernel32.lib
INCLUDELIB user32.lib

.data
    buffer byte 100 dup(0)
    prompt byte "Enter a string: ",0
    result byte "Sum of digits: ",0

.code
main proc
    ; Display prompt
    mov edx, offset prompt
    call WriteString

    ; Read input
    mov edx, offset buffer
    mov ecx, lengthof buffer
    call ReadString

    ; Process string
    mov esi, edx        ; string pointer
    xor eax, eax        ; sum = 0

count_digits:
    movzx ebx, byte ptr [esi]
    cmp bl, 0           ; null terminator?
    je display_sum
    
    cmp bl, '0'
    jb next_char
    cmp bl, '9'
    ja next_char
    
    and bl, 0Fh         ; ASCII to digit
    add al, bl          ; add to sum

next_char:
    inc esi
    jmp count_digits

display_sum:
    mov edx, offset result
    call WriteString
    call WriteDec       ; display sum in EAX
    call Crlf

    invoke ExitProcess, 0
main endp
end main