TITLE

; Name: 
; Date: 
; ID: 
; Description: 

INCLUDE Irvine32.inc
INCLUDELIB Irvine32.lib

; these two lines are only necessary if you're not using Visual Studio
INCLUDELIB kernel32.lib
INCLUDELIB user32.lib

.data
	; data declarations go here
	
.code
main PROC
	
	; code goes here
	xor eax, eax
    mov AL, 10101110b
    shl AL, 1
    call writeBin
	call DumpRegs ; displays registers in console

    xor eax, eax
    mov AL, 10101110b
    shr AL, 1
    call writeBin
	call DumpRegs

    xor eax, eax
    mov CL, 3
    mov AL, 01101101b
    shL AL, CL
    call writeBin
	call DumpRegs

    mov AX, 1011110101011001b
    shr AX, 5
    call writeBin
    call DumpRegs

    mov AX, 1011110101011001b
    ror AX, 5
    call writeBin
    call DumpRegs


	exit

main ENDP
END main