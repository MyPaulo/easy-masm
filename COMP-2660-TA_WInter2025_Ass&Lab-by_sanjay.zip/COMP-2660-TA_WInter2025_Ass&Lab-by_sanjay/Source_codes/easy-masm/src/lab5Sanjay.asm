TITLE

; Name: 
; Date: 
; ID: 
; Description: 

INCLUDE Irvine32.inc
INCLUDELIB Irvine32.lib

; These two lines are only necessary if you're not using Visual Studio
INCLUDELIB kernel32.lib
INCLUDELIB user32.lib

.data
    
    ; Data declarations
    Transaction DWORD 500, -300, 1200, -600, 800, -200, 1500, -750, 300 ; Transactions
    arrayLength DWORD 9 ; Length of the Transactions array
    LargeWithdrawalsSum DWORD 0 ; Sum of large withdrawals (< -500)
    RegularTransactionCount DWORD 0 ; Count of regular transactions
    LargeDepositsSum DWORD 0 ; Sum of large deposits (> 1000)
    StackChecker DWORD 0 ; Counter for stack operations

    ; Messages to display
    msgLargeWithdrawals BYTE "The total sum of large withdrawals (transactions less than -500): ", 0
    msgRegularTransactions BYTE "The count of regular transactions: ", 0
    msgLargeDeposits BYTE "The total sum of large deposits (deposits over 1000): ", 0

.code
main PROC

    ; Set up loop variables
    ;MOV ECX, arrayLength ; ECX holds the array length for loop counter
	MOV ECX, LENGTHOF Transaction; ECX holds the array length for loop counter
    CMP ECX, 0           ; Check if there are any transactions to process
    JE PrintResults      ; If ECX is 0, skip to printing results

    LEA ESI, Transaction ; ESI points to the start of Transactions
    MOV LargeWithdrawalsSum, 0 ; Set large withdrawal sum to 0
    MOV RegularTransactionCount, 0 ; Set regular count to zero
    MOV LargeDepositsSum, 0 ; Set large deposits sum to zero
    MOV StackChecker, 0 ; Initialize stack counter

    ; Loop through the transactions
L1:
    ; Load the current transaction value into EAX
    MOV EAX, [ESI]
    ADD ESI, TYPE Transaction ; Move ESI to the next transaction 

    ; Transaction Categorization
    CMP EAX, 1000 ; Check if transaction is a large deposit (> 1000)
    JG LargeDeposit

    CMP EAX, -500 ; Check if transaction is a large withdrawal (< -500)
    JL LargeWithdrawal

    ; If neither, it's a regular transaction
    INC RegularTransactionCount
    JMP Continue ; Jump to next iteration

LargeDeposit: 
    PUSH EAX ; Push the large deposit onto the stack
    INC StackChecker ; Increment stack counter
    JMP Continue ; Jump to next iteration

LargeWithdrawal: 
    ADD LargeWithdrawalsSum, EAX ; Add to large withdrawals sum

Continue:
    LOOP L1 ; Decrement ECX and loop if not zero 

    ; Pop all values from the stack and add them to the LargeDepositsSum
    MOV ECX, StackChecker ; Load the stack counter into ECX
    CMP ECX, 0            ; Check if the stack counter is zero
    JE PrintResults       ; If ECX is 0, go to PrintResults
    PopLoop:
        POP EAX             ; Pop the top value from the stack
        ADD LargeDepositsSum, EAX ; Add it to the sum of large deposits
        LOOP PopLoop          ; Decrement ECX and loop if not zero
    ;another way using jmp
    ; Pop all values from the stack and add them to the LargeDepositsSum
    COMMENT @
    PopStackContent:
        ;CMP StackChecker, 0 ; Check if the stack counter is zero
        ;JE PrintResults     ; If StackChecker is 0, go to PrintResults
        ;POP EAX             ; Pop the top value from the stack
        ;ADD LargeDepositsSum, EAX ; Add it to the sum of large deposits
        ;DEC StackChecker    ; Decrement stack counter
        ;JMP PopStackContent
 	    @
PrintResults:
    ; Display the total sum of large withdrawals
    LEA EDX, msgLargeWithdrawals
    CALL WriteString
    MOV EAX, LargeWithdrawalsSum
    CALL WriteInt
    CALL Crlf

    ; Display the count of regular transactions
    LEA EDX, msgRegularTransactions
    CALL WriteString
    MOV EAX, RegularTransactionCount
    CALL WriteInt
    CALL Crlf

    ; Display the total sum of large deposits
    LEA EDX, msgLargeDeposits
    CALL WriteString
    MOV EAX, LargeDepositsSum
    CALL WriteInt
    CALL Crlf

    ; Exit the program
    CALL DumpRegs ; Displays registers in console
    EXIT

main ENDP
END main