
TITLE
; Name: 
; Date: 
; ID: 
; Description: 

INCLUDE Irvine32.inc
INCLUDELIB Irvine32.lib

; these two lines are only necessary if you're not using Visual Studio
INCLUDELIB kernel32.lib
INCLUDELIB user32.lib
.data
	; data declarations go here
    align 4
    var1 BYTE 12h
    var2 WORD 3456h
    var3 DWORD 789ABCDEh
    arr1 DWORD 10, 21, 30, 41, 50, 61, 70, 81, 90, 101
    str1 BYTE "Assembly Programming", 0
    matrix DWORD 4 DUP(4 DUP(?)) ; 4x4 Matrix
    uninit DWORD ?

     COMMENT @
    Explain the effect of align 4 on var1, var2, and var3. You
    can create memory map and explain.
    answer: Align 4 directive is used to ensure variables are arranged or aligned on a 4-byte boundary 
    @

.code

; Print the matrix using DumpMem
PrintArray PROC
    lea esi, matrix
    mov ecx, LENGTHOF matrix
    mov ebx, TYPE matrix
    call DumpMem
    ret
PrintArray ENDP


MatrixFill PROC
    ; Set up the loop counter
    mov ecx, LENGTHOF matrix ;ecx=16
    ; Loop through matrix and set each element to its index + 1
    lea esi, matrix ;Set the source index to the start of the matrix
    xor eax, eax ;set eax to zero
    L1:
        inc eax; 
        mov [esi], eax ;Write the value to the current element
        add esi, type matrix ;Move to the next element
        Loop L1 ;Repeat until all elements have been filled

    lea eax, matrix
    ret
MatrixFill ENDP

main PROC

    ;Print the matrix before initialization
    call PrintArray

	;Initialize the matrix
    call MatrixFill

    ;Print the matrix after initialization
    call PrintArray

	call DumpRegs ; displays registers in console
	exit
main ENDP
END main



