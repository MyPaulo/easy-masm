TITLE

; Name: 
; Date: 
; ID: 
; Description: 

INCLUDE Irvine32.inc
INCLUDELIB Irvine32.lib

; these two lines are only necessary if you're not using Visual Studio
INCLUDELIB kernel32.lib
INCLUDELIB user32.lib

.data

 A DWORD 12345678h
 B WORD 0ABCDh, "E"
 Co SBYTE -7, +13, '-7'

 bo SWORD 1234h, -1

 operands dd 6.0, 2.0, 3.0, 4.0  ; Floating-point values for computation
 result dd 0.0                   ; Variable to store the final result


.code
main PROC
    XOR EAX, EAX
    XOR EBX, EBX
    XOR EDX, EDX
    mov eax, A
    mov BX, WORD PTR A+1

    mov AX, bo

    mov DL, 23h
    shl DL, 2

    ;mov DH, 0F8h
    ;SAL DH, 1


    ; Load 2.0 and 3.0 onto the FPU stack
    fld  [operands + 4]        ; Load 2.0 onto the FPU stack
    fld  [operands + 8]        ; Load 3.0 onto the FPU stack

    ; Perform 2.0 + 3.0
    fadd                           ; Stack top now contains 2.0 + 3.0

    ; Load 6.0 and multiply
    fld  [operands]           ; Load 6.0 onto the FPU stack
    fmul                           ; Stack top now contains 6.0 * (2.0 + 3.0)

    ; Load 4.0 and subtract
    fld  [operands + 12]      ; Load 4.0 onto the FPU stack
    fsub                           ; Stack top now contains 6.0 * (2.0 + 3.0) - 4.0
    call showfpustack
    ; Store the result
    fstp  [result]            ; Pop the FPU stack and store the result in memory
   



    LEA ESI, A   ; Point to the array
    mov ecx, SIZEOF A              ; 5 DWORDs = 20 bytes
    call DumpMem            ; Display memory contents
   Call DumpRegs

    INVOKE ExitProcess,0
    
main ENDP
END main
