TITLE

; Name: 
; Date: 
; ID: 
; Description: Evaluate Y = 6.0 * (2.0 + 3.0) - 4.0 using postfix
               ;postfix expression = 2.0 3.0 + 6.0 * 4.0 -

INCLUDE Irvine32.inc
INCLUDELIB Irvine32.lib

; these two lines are only necessary if you're not using Visual Studio
INCLUDELIB kernel32.lib
INCLUDELIB user32.lib

.data
	; data declarations go here
	A0 real4 2.0
	A1 real4 3.0
	A2 real4 6.0
	A3 real4 4.0
	result real4 ?

	msg DB "The result of Postfix expression is = ",0 ; this is extra
	
.code
main PROC
	
	; code goes here
	;Note using fadd, fmul, fsub with usinG parameters like Fadd ST(0), ST(1) does the operation store result in STO and then pop ST1
	finit
	;Call ShowFpuStack
	fld A0
	;Call ShowFpuStack
	fld A1
	;Call ShowFpuStack
	fadd    ;fadd  ST(0), ST(1)   ST(0) = +5.0000000E+000 = 5.0
	;Call ShowFpuStack
	COMMENT @
	fld A2
	fmul  ;fmul  ST(0), ST(1)         ST(0) = +3.0000000E+001 = 30.0
	;Call ShowFpuStack
	fld A3
	;call ShowFpuStack
	fsub;fxch ST(1)-> swap ST1 and STO values.  fub ST(0), ST(1) = gives ST(0)= -2.6000000E+001, if you want to make it postive swap them first with fxch
	;call ShowFpuStack 
	fst result;  store ST(0) value in result but doesn't not pop or remove value in ST(0) unlike fstp does opposite 

	;extra you can remove 
	lea edx, msg
	call WriteString
	;extra end here
	mov eax, result ; result in eax
	call WriteFloat ; display decimal or real number result
	call Crlf
	
	;call ShowFpuStack
	finit ;empty the stack 
	@
	call ShowFpuStack
	call DumpRegs ; displays registers in console

	exit

main ENDP
END main
