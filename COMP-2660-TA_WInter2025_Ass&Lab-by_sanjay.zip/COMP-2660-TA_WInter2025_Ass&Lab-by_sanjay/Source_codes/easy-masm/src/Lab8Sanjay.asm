TITLE

; Name: 
; Date: 
; ID: 
; Description: 

COMMENT @
int func (int n){
	if(n == 0)
		return 0;
	n = n+ func(n-1);
	return n;
}
@
INCLUDE Irvine32.inc
INCLUDELIB Irvine32.lib

; these two lines are only necessary if you're not using Visual Studio
INCLUDELIB kernel32.lib
INCLUDELIB user32.lib

.data
    msgInput BYTE "Enter a positive integer: ", 0 ; Prompt user message
    n DWORD ?
    msgResult BYTE "The result sum of the func is: ", 0 ; dipslay meaningful message to user with result 
    ;space db " (",0 
    ;space1 db ")",0 
.code
main PROC
    call ReadInput ; call ReadInput to get user input
    push n       ; push the vale n or already in eax unto stack 
    call func      ; call func to calculate sum of the number down to 0
    call DisplayResult ;call Displayresult to show  the result of func

    exit
main ENDP

; Get input from the user
ReadInput PROC
    lea edx, msgInput
    call WriteString
    call ReadInt       ;ReadInput take user input and store in eax
    mov n, eax        ; move the value in eax to variable n
    ret                ;return back to main but on line 31 above 
ReadInput ENDP    

func PROC
    push ebp  ;push ebp to establish a stack frame  or save previous state
    mov  ebp, esp ; set ebp to esp for stable reference point
    mov  eax, [ebp+8]   ; move the value of n into eax
    cmp  eax, 0          ; Check if n == 0
    jl check_negative   ; jmp to check_negative if n < 0 
    jne  continue        ; If not zero, continue
    mov  eax, 0         ; If zero, return 0 -> base case 
    jmp  end_func       ; Jump to end_func to return the result

check_negative:     
    mov eax, 0         ; If n < 0, set eax to 0 (handle negative case)
    jmp end_func         

continue: 
    dec  eax            ; n = n - 1
    push eax           ; Push n-1 onto the stack
    call func          ; Call func(n-1) recursively 

    
    ; Instructions from this point on execute when each
    ; recursive call returns.
    add eax, [ebp+8]      ; Add n to the result -> accumulator 
    
end_func:
    pop  ebp              ; Restore or return EBP
    ret  4                ; Clean up stack
func ENDP

DisplayResult PROC
    lea edx, msgResult
    call WriteString
    call WriteDec        ;Print the value of eax
    ;lea edx, space
    ;call WriteString 
    ;call WriteHex
    ;lea edx, space1
    ;call WriteString 
    ;call Crlf        
    call Crlf  
    ret
DisplayResult ENDP

END main