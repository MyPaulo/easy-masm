TITLE Parity Calculation

; Name: 
; Date: 
; ID: 
; Description: Calculate the parity of a 32-bit memory operand

INCLUDE Irvine32.inc
INCLUDELIB Irvine32.lib
INCLUDELIB kernel32.lib
INCLUDELIB user32.lib

.data
    Test1 DWORD 13456785h

.code
main PROC
    xor eax, eax
    call Parity_check

    call DumpRegs       ; Display registers in console
    exit
main ENDP

Parity_check PROC
    xor al, al          ; Clear AL register
    lea esi, Test1      ; Load address of Test1 into ESI

    mov al, BYTE PTR [esi]      ; Load first byte of Test1 into AL
    xor al, BYTE PTR [esi + 1]  ; XOR AL with second byte
    xor al, BYTE PTR [esi + 2]  ; XOR AL with third byte
    xor al, BYTE PTR [esi + 3]  ; XOR AL with fourth byte
    ; AL now contains the parity of the 32-bit value in Test1
    ret
Parity_check ENDP

END main




COMMENT @

TITLE

; Name: 
; Date: 
; ID: 
; Description: 

INCLUDE Irvine32.inc
INCLUDELIB Irvine32.lib

; these two lines are only necessary if you're not using Visual Studio
INCLUDELIB kernel32.lib
INCLUDELIB user32.lib

.data
    
	; data declarations go here
	Test1 DWORD 13456785h
.code
main PROC
    XOR EAX, EAX
    XOR EBX, EBX
    XOR ECX, ECX
    XOR EDX, EDX
	; code goes here
    lea esi, Test1
    mov al, BYTE PTR Test1
    mov bl, BYTE PTR Test1 + 1
    xor al, bl
    mov cl, BYTE PTR Test1 + 2
    xor al, cl
    mov dl, BYTE PTR TEST1 + 3
    xor al,dl
    call DumpRegs ; displays registers in console

	exit

main ENDP
END main

@


COMMENT @

TITLE Parity Calculation

; Name: 
; Date: 
; ID: 
; Description: Calculate the parity of a 32-bit memory operand

INCLUDE Irvine32.inc
INCLUDELIB Irvine32.lib
INCLUDELIB kernel32.lib
INCLUDELIB user32.lib

.data
    Test1 DWORD 4h
    msgEven BYTE "Parity is even", 0
    msgOdd BYTE "Parity is odd", 0

.code
main PROC
    xor eax, eax
    call Parity_check

    call Check_Parity   ; Check and print the parity flag

    call DumpRegs       ; Display registers in console
    exit
main ENDP

Parity_check PROC
    xor al, al          ; Clear AL register
    lea esi, Test1      ; Load address of Test1 into ESI

    mov al, BYTE PTR [esi]      ; Load first byte of Test1 into AL
    xor al, BYTE PTR [esi + 1]  ; XOR AL with second byte
    xor al, BYTE PTR [esi + 2]  ; XOR AL with third byte
    xor al, BYTE PTR [esi + 3]  ; XOR AL with fourth byte
    ; AL now contains the parity of the 32-bit value in Test1
    ret
Parity_check ENDP

Check_Parity PROC
    pushfd              ; Push EFLAGS to the stack
    pop eax             ; Pop EFLAGS into EAX
    test eax, 004h      ; Test the parity flag (PF)
    jz Parity_Odd       ; Jump if PF is 0 (odd parity)
    ; If PF is 1 (even parity)
    mov edx, OFFSET msgEven
    call WriteString
    jmp End_Check_Parity

Parity_Odd:
    mov edx, OFFSET msgOdd
    call WriteString

End_Check_Parity:
    ret
Check_Parity ENDP

END main
@
