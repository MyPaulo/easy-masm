TITLE Array Processing

; Name: 
; Date: 
; ID: 
; Description: Sum positive values and count negative values in an array

INCLUDE Irvine32.inc
INCLUDELIB Irvine32.lib

; these two lines are only necessary if you're not using Visual Studio
INCLUDELIB kernel32.lib
INCLUDELIB user32.lib

.data
    
    myArray DWORD 10, -20, 4, 5, -35, 44, -60, 2, 0, 23 ; Array of 10 elements
    countNegative DWORD ? ; Variable to count negative values
    sumPostive DWORD ? ; Variable to sum positive values

	msgPostive BYTE "The sum of postive values is = ",0
	msgNegative DB "The count of negative values is = ",0


.code
main PROC
    
    MOV sumPostive, 0 ; Initialize sumPositive to 0
    
    MOV countNegative, 0 ; Initialize countNegative to 0
    
    LEA ESI, myArray ; Load address of myArray into ESI
    
    MOV ECX, LENGTHOF myArray ; Load the length of myArray into ECX, ecx = 10

L1: 
    MOV EAX, [ESI] ; Load the current array element into EAX
    ADD ESI, TYPE myArray ; Move to the next array element
    CMP EAX, 0 ; Compare the current element with 0
    JL countN ; If the element is negative, jump to countN
    ADD sumPostive, EAX ; If the element is positive, add it to sumPositive
    JMP next ; Jump to the next iteration
countN: 
    INC countNegative ; Increment the count of negative values
next:
    LOOP L1 ; Loop until all elements are processed

    ; Display the sum of positive values
	LEA EDX, msgPostive
	CALL WriteString
    MOV EAX, sumPostive
    CALL WriteDec
    CALL CRLF

    ; Display the count of negative values
	LEA EDX, msgNegative
	CALL WriteString
    MOV EAX, countNegative
    CALL WriteDec
	CALL CRLF
    
    CALL DumpRegs ; Display registers in console

    exit ; Exit the program

main ENDP
END main













































































































































































































;This is code is from AI which is correct compare to what i have up written by me

COMMENT @

TITLE Array Processing

; Name: 
; Date: 
; ID: 
; Description: Sum positive values and count negative values in an array

INCLUDE Irvine32.inc
INCLUDELIB Irvine32.lib

; these two lines are only necessary if you're not using Visual Studio
INCLUDELIB kernel32.lib
INCLUDELIB user32.lib

.data
    array DWORD 10, -20, 4, 5, -35, 44, -60, 2, 0, 23
    sum DWORD 0
    negCount DWORD 0
    arraySize DWORD 10

.code
main PROC
    mov ecx, arraySize
    mov esi, OFFSET array
    xor eax, eax
    xor ebx, ebx

L1:
    mov edx, [esi]
    cmp edx, 0
    jl isNegative
    add eax, edx
    jmp nextElement

isNegative:
    inc ebx

nextElement:
    add esi, TYPE DWORD
    loop L1

    mov sum, eax
    mov negCount, ebx

    call DumpRegs ; displays registers in console

    exit

main ENDP
END main
@