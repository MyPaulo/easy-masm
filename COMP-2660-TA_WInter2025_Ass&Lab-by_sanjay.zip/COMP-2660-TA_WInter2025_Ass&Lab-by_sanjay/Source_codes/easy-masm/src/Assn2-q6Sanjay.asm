TITLE Parity_Checking.asm

; Name: 
; Date: 
; ID: 
; Description: Implements a loop to check and update the value of N based on conditions

INCLUDE Irvine32.inc
INCLUDELIB Irvine32.lib

; these two lines are only necessary if you're not using Visual Studio
INCLUDELIB kernel32.lib
INCLUDELIB user32.lib

.data
    A SDWORD 2
    B SDWORD 8
    N SDWORD 4

.code
main PROC
    mov eax, N          ; Load N into eax
LoopStart:
    cmp eax, 0          ; Compare N with 0
    jle LoopEnd         ; If N <= 0, exit loop

    cmp eax, 3          ; Compare N with 3
    je SubtractOne      ; If N == 3, go to SubtractOne

    mov ebx, A          ; Load A into ebx
    cmp eax, ebx        ; Compare N with A
    jl SubtractTwo      ; If N < A, go to SubtractTwo

    mov ebx, B          ; Load B into ebx
    cmp eax, ebx        ; Compare N with B
    jg SubtractTwo      ; If N > B, go to SubtractTwo

SubtractOne:
    sub eax, 1          ; N = N - 1
    jmp UpdateN         ; Jump to update N

SubtractTwo:
    sub eax, 2          ; N = N - 2

UpdateN:
    mov N, eax          ; Store the updated N
    jmp LoopStart       ; Repeat the loop

LoopEnd:
    mov eax, N          ; Move final N value to eax
    call WriteInt       ; Print the final value of N
    call Crlf           ; Print a newline
    call DumpRegs       ; Display registers in console

    exit
main ENDP
END main
