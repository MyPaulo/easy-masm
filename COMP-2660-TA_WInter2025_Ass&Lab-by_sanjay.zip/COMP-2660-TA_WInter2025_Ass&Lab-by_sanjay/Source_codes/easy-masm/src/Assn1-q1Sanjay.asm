TITLE Array Operations

; Name: 
; Date: 
; ID: 
; Description: This program performs addition and subtraction on elements of an array using both direct and indirect addressing.

INCLUDE Irvine32.inc
INCLUDELIB Irvine32.lib

; These two lines are only necessary if you're not using Visual Studio
INCLUDELIB kernel32.lib
INCLUDELIB user32.lib

.data
array DWORD 5, 10, 15, 20, 25  ; Initialize the array with 5 DWORD elements

.code
main PROC
    ; Step 2: Use direct addressing to access the first and second elements and add them together
    mov eax, array          ; Load the first element (5) into EAX
    add eax, array[4]       ; Add the second element (10) to EAX
    
    ; Step 3: Use indirect addressing to subtract the third element from the result
    lea esi, array          ; Load the address of the array into ESI
    sub eax, [esi + 8]      ; Subtract the third element (15) from EAX
    
    ; Step 4: Store the result in the fifth element of the array
    mov [esi + 16], eax     ; Store the result in the fifth element of the array
    
    ; Step 5: Display the result by moving the value of the fifth element into EAX and exiting the program
    mov eax, [esi + 16]     ; Move the value of the fifth element into EAX
    call DumpRegs          ; Display registers

    mov ECX, LENGTHOF array
    LEA ESI, array
    L2:
        MOV EAX, [ESI]
        call WriteDec
        ADD ESI, TYPE array
        CALL CRLF
        ;ADD ESI, TYPE resultArray
        loop L2

    LEA ESI, array   ; Point to the array
    mov ecx, SIZEOF array              ; 5 DWORDs = 20 bytes
    call DumpMem            ; Display memory contents
    exit
main ENDP
END main
