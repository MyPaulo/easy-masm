TITLE

; Name: 
; Date: 
; ID: 
; Description: 

INCLUDE Irvine32.inc
INCLUDELIB Irvine32.lib

; these two lines are only necessary if you're not using Visual Studio
INCLUDELIB kernel32.lib
INCLUDELIB user32.lib


.data
array DWORD 4 DUP(0)
.code
 
main PROC
     mov  eax,10
     mov  esi,0
     call proc_1
     add  esi,4
     add  eax,10
     mov  array[esi],eax
     LEA ESI, array   
    mov ecx, SIZEOF array             
    call DumpMem 
     INVOKE ExitProcess,0
main ENDP
 
proc_1 PROC
     call proc_2
     add  esi,4
     add  eax,10
     mov  array[esi],eax
     ret
proc_1 ENDP
proc_2 PROC
     call proc_3
     add  esi,4
     add  eax,10
     mov  array[esi],eax
     ret
proc_2 ENDP
proc_3 PROC
     mov  array[esi],eax
     ret
proc_3 ENDP
END main




















end main