TITLE Bubble Sort
; Name: 
; Date: 
; ID: 
; Description: 

INCLUDE Irvine32.inc
INCLUDELIB Irvine32.lib

; these two lines are only necessary if you're not using Visual Studio
INCLUDELIB kernel32.lib
INCLUDELIB user32.lib

.data
	; data declarations go here
	myArray  SDWORD 5, -3, 8, 12, -7, 6, 4, 10, 2, 0
    msg BYTE "Original Array: ",0
    msg1 DB "Sorrted Array: ",0

    tMsg1 BYTE "Before Swap: ", 0
    tMsg2 BYTE "After Swap: ", 0
.code

;Procedure for printing content of an array
PrintArray PROC
    push ebp
    mov ebp, esp
    pushad

    mov esi, [ebp+12] ; Load address of the array into ESI
    mov ecx, [ebp+8] ; Load length of the array into ECX

 ;Loop through the array and print each element
    L1:
    
        mov eax, [esi]; Move the current element into EAX
        call WriteInt ; Call WriteInt to print the integer in EAX
        mov al, ' ';Move a space character into AL
        call WriteChar  ;Call WriteChar to print space 
        add esi, TYPE DWORD ;Move to the next element in the array
        loop L1 ;Decrement ECX and loop if ECX is not zero

        call CRLF
        popad
        pop ebp
    ret 8
PrintArray ENDP


;Swap Procedure
Swap PROC 
    push ebp
    mov ebp, esp
    pushad
    ;Load addresses of two elements
    mov esi, [ebp+12] ;Address of first element
    mov edi, [ebp+8]  ;Address of second element


    ;Load the values into registers
    mov eax, [esi] ;Load first element into EAX
    mov edx, [edi] ;Load second element into EDX

    ;Swap using xchg
    xchg eax, edx ;Exchange the values in EAX and EDX

    ; Store the swapped values back into memory
    mov [esi], eax 
    mov [edi], edx 

    popad
    pop ebp
    ret 8
Swap ENDP 

BubbleSort Proc
    push ebp
    mov ebp, esp
    pushad

    mov esi, [ebp + 12] ;address of the array into ESI
    mov ecx, [ebp + 8] ;length of the array into ECX
    
    dec ecx ;Outer loop runs n-1 times

    Outer_i_Loop:
        mov edi, ecx ;loop counter n-i-1
        mov ebx, esi ; EBX points to the start of the array
    Inner_J_Loop:
        mov eax, [ebx] ;Load current element array[j]
        mov edx, [ebx + 4] ;Load next element array[j+1]
        cmp eax, edx ; Compare array[j] and array[j+1]
        jle Donothing ;If array[j] <= array[j+1], no swap needed

        ; Call Swap procedure to swap array[j] and array[j+1]
        push ebx ; Push address of array[j]
        lea edx, [ebx + 4] ; Load address of array[j+1] into EDX
        push edx ; Push address of array[j+1]
        call Swap ;Call Swap proc

    Donothing:
        add ebx, TYPE myArray ;Move to the next element
        dec edi ;decrement inner loop counter
        jnz Inner_J_Loop ; Repeat inner loop if counter > 0

        loop Outer_i_Loop

        popad
        pop ebp
    ret 8
BubbleSort ENDP


main PROC
	
	; code goes here
	xor eax, eax
    ; Display the original array before sorting
    push OFFSET myArray
    push LENGTHOF myArray
    lea edx, msg
    call WriteString
    call PrintArray

    ; Call BubbleSort
    push OFFSET myArray
    push LENGTHOF myArray
    call BubbleSort

    ; Display the sorted array
    lea edx, msg1
    call WriteString
    push OFFSET myArray
    push LENGTHOF myArray
    call PrintArray


   ;Testing swap using original array 
   ;Note that before swap will conatined sorted array since bubblesort is called above
   lea edx, tMsg1
   call WriteString
    push OFFSET myArray
    push LENGTHOF myArray
    call PrintArray

    push OFFSET myArray
    push OFFSET myArray + 4 ;swap -7 and -3 or swap first and second element of the array
    call swap

    lea edx, tMsg2
    call WriteString
    push OFFSET myArray
    push LENGTHOF myArray
    call PrintArray

 call DumpRegs ; Displays registers in console

	exit

main ENDP
END main
