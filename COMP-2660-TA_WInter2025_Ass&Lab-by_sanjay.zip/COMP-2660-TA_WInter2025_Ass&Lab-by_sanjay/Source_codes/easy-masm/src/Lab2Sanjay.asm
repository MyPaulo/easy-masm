
TITLE
; Name: paul 
; Date: 02/10/24
; ID: 11xxxxxxxxxxxxx
; Description: understand the content of a register and observe chanage of flags 

INCLUDE Irvine32.inc
INCLUDELIB Irvine32.lib

; these two lines are only necessary if you're not using Visual Studio
INCLUDELIB kernel32.lib
INCLUDELIB user32.lib

.code
main PROC
	mov eax, 12345678h
	mov ax, 1122h
	mov bl, al
	mov bl, ah
	mov al, 89h
	add al, 10h
	sub al, al
	mov al, 98h
	add al, 89h


	call DumpRegs ; displays registers in console

	exit

	;INVOKE ExitProcess, 0
main ENDP
END main