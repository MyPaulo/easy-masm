TITLE Lab 3 - MASM Arithmetic without MUL

; Name: Surbhi Surbhi
; Date: 28th January 2025
; ID: 110124919


INCLUDE Irvine32.inc
INCLUDELIB Irvine32.lib

; these two lines are only necessary if you're not using Visual Studio
INCLUDELIB kernel32.lib
INCLUDELIB user32.lib


.data
    A DWORD 20
    B DWORD 10
    varC DWORD 5  
    D DWORD 50
    E DWORD 15
    Result DWORD ?  ; Final result

    ptrA DWORD A
    ptrB DWORD B
    ptrC DWORD varC  
    ptrD DWORD D
    ptrE DWORD E

.code
main PROC
    ; Initialize registers
    mov ebx, ptrA
    mov eax, [ebx]
    mov edi, ptrB  ; Load address of B into EDI
    add eax, [edi]        ; sumAB = A + B
    call DumpRegs
    ; Store sumAB in EBX
    mov ebx, eax          ; EBX = sumAB

    ; Multiply sumAB * C using loop (without MUL)
    mov esi, ptrC  ; Load address of C
    mov ecx, [esi]        ; Load C into ECX (loop counter)
    mov edx, 0            ; Clear EDX to hold the product

multiply_loop:
    add edx, eax          ; Accumulate sumAB in EDX
    loop multiply_loop

    ; Store prodABC in EDX
    mov ecx, edx          ; EBX = prodABC
    ; Compute diffDE = D - E
    mov esi, ptrD  ; Load address of D
    mov edi, ptrE  ; Load address of E
    mov eax, [esi]        ; Load D into EAX
    sub eax, [edi]        ; EAX = D - E (diffDE)

    ; Compute final result: Result = prodABC - diffDE
    sub ecx, eax          ; EBX = prodABC - diffDE

    ; Store final result in memory
    mov Result, ecx

    ; Display the result
    mov eax, Result
    call WriteHex  ; Display result in hex
    call Crlf
    call WriteDec
   

    ; Display register values for debugging
    call DumpRegs

    exit
main ENDP
END main
