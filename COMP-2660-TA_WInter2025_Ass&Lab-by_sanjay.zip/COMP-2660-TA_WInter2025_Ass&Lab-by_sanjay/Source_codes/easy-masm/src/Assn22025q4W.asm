

TITLE
; Name: 
; Date: 
; ID: 
; Description: 

INCLUDE Irvine32.inc
INCLUDELIB Irvine32.lib

; these two lines are only necessary if you're not using Visual Studio
INCLUDELIB kernel32.lib
INCLUDELIB user32.lib
.data
	; data declarations go here
    align 4
    var1 BYTE 12h
    var2 WORD 3456h
    var3 DWORD 789ABCDEh
    arr1 DWORD 10, 21, 30, 41, 50, 61, 70, 81, 90, 101
    str1 BYTE "Assembly Programming", 0
    matrix DWORD 4 DUP(4 DUP(?)) ; 4x4 Matrix
    uninit DWORD ?
    arr2 DWORD 10 DUP (?) ;Array to copy arr1 into
    arr3 DWORD 10 DUP (?) ; Array to store even numbers in reverse order
.code
;Procedure for printing content of an array
PrintArray PROC
    push ebp
    mov ebp,esp
    pushad

    mov esi, [ebp+12] ;Load address of the array into ESI
    mov ecx, [ebp+8] ;; Load length of the array into ECX
  

    call CRLF
    L1:
        mov eax, [esi]
        call WriteDec
        mov al, ' '
        call WriteChar
        add esi, TYPE DWORD
        Loop L1

        call CRLF
        popad
        pop ebp
    ret 8
PrintArray ENDP

;Procedure for pushing even numbers from arr1 onto the stack
ReverseEvenNumber PROC
    lea esi, arr1 ;Load address of arr1 into ESI
    mov ecx, LENGTHOF arr1
    mov edx, 0 

    L1:
        mov eax, [esi] ;load first value from arr1 into EAX
        test eax, 1 ; Test if the number is even? we can use and eax, 1?
        jnz skip_odd ; If odd, skip to the next number
        push eax ;Push even number onto the stack
        inc edx ; Increment stack size
    skip_odd:
        add esi, TYPE arr1 ; Go to the next index in arr1
        Loop L1

    lea edi, arr3 ;Load address of arr3 into EDI
    mov ecx, edx
    L2:
        pop eax ; Pop value from the stack into EAX
        mov [edi], eax ; Store the value in arr3
        add edi, TYPE arr3 ;Go to the next index in arr3
        Loop L2

    mov eax, edx ; Return the number of even numbers in EAX

    ret
ReverseEvenNumber ENDP

main PROC
    ; display the original array before copying
    push OFFSET arr1
    push LENGTHOF arr1
    call PrintArray

    ;Copy even numbers from arr1 to arr3 in reverse orde
    call ReverseEvenNumber

    ;Display the reversed array
    push OFFSET arr3
    push LENGTHOF arr3
    call PrintArray

	;call DumpRegs ; displays registers in console
	exit
main ENDP
END main



